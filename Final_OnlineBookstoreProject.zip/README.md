
# Book Service (Microservice - Spring Boot)

This is a part of the Online Bookstore Backend project. It handles book-related operations.

## Features
- CRUD APIs for Book entity
- PostgreSQL as the database
- Spring Boot 3 + Java 17 + Spring Data JPA

## How to Run

1. Make sure PostgreSQL is running with database `bookdb`, username `postgres`, and password `postgres`
2. Navigate to the `book-service` folder
3. Run using Maven:

```bash
mvn spring-boot:run
```

API will be available at `http://localhost:8081/api/books`
