package com.bookstore.bookservice;

public class Application {
    public static void main(String[] args) {
        System.out.println("book-service started...");
    }
}